# Gangadhar Naraveni — Personal Portfolio

## Files
- `index.html`: responsive portfolio and link-in-bio website in one file.
- Edit text by clicking/tapping content marked editable in the browser, then press **Save edits on this device**. These edits are local to that browser/device; they do not update the published website for visitors.
- To make public changes, edit `index.html` and upload/commit it to your hosting provider.

## Publish with GitHub Pages (free static hosting)
1. Sign in to GitHub and create a **public** repository named `gangadhar-portfolio`.
2. Upload `index.html` to the repository root and commit.
3. Open repository **Settings → Pages**.
4. Under Build and deployment, select deployment from the `main` branch and `/ (root)` folder, then save.
5. Wait for GitHub Pages to publish the site.

## Connect `gangadharnaraveni.in`
1. First check availability and register `gangadharnaraveni.in` with a registrar listed by the official .IN Registry: https://www.registry.in/accredited-registrars
2. In the GitHub repository, open **Settings → Pages → Custom domain**, enter `gangadharnaraveni.in`, and save.
3. At the domain registrar's DNS settings, create the DNS records required by GitHub Pages. GitHub's official instructions currently list these four A records for the root/apex domain:
   - `185.199.108.153`
   - `185.199.109.153`
   - `185.199.110.153`
   - `185.199.111.153`
4. To support `www.gangadharnaraveni.in`, add a CNAME record for host `www` pointing to your GitHub Pages hostname (`YOUR-USERNAME.github.io`). Replace this with your actual GitHub username's Pages hostname.
5. Return to Settings → Pages and enable **Enforce HTTPS** once the option becomes available.
6. DNS changes can take up to 24 hours to propagate.

Official docs:
- .IN accredited registrars: https://www.registry.in/accredited-registrars
- GitHub custom domain setup: https://docs.github.com/en/pages/configuring-a-custom-domain-for-your-github-pages-site
- GitHub custom domain DNS details: https://docs.github.com/en/pages/configuring-a-custom-domain-for-your-github-pages-site/managing-a-custom-domain-for-your-github-pages-site

## Before going live
- Check domain availability; it has not been confirmed by this package.
- Verify all personal details, course names, dates, and Rotaract titles.
- Replace `your-email@example.com` with an email you are comfortable publishing, or remove it.
- The site currently includes your LinkedIn profile and an Instagram handle supplied in the project context. Verify those links before publishing.
- Avoid publishing phone numbers, home address, student ID, or other private information.
